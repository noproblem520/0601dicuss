/*
* Copyright (C) 2016 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package com.example.android.todolist;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.android.todolist.data.TaskContract;


public class AddTaskActivity extends AppCompatActivity {





    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);
    }


    /**
     * onClickAddTask is called when the "ADD" button is clicked.
     * It retrieves user input and inserts that new task data into the underlying database.
     */
    public void onClickAddTask(View view) {
        // Not yet implemented
        // Check if EditText is empty, if not retrieve input and store it in a ContentValues object
        // If the EditText input is empty -> don't create an entry
        String name = "";
        int population = 0;
        double area= 0;
        double GDP = 0.0 ;
        double density = 0.0;
        try {
            name = ((EditText) findViewById(R.id.editTextTaskName)).getText().toString();
            population = Integer.valueOf(((EditText) findViewById(R.id.editTextTaskPopulation)).getText().toString());
            area = Double.valueOf(((EditText) findViewById(R.id.editTextTaskArea)).getText().toString());
            GDP = Double.valueOf(((EditText) findViewById(R.id.editTextTaskGDP)).getText().toString());
            density = Double.valueOf(((EditText) findViewById(R.id.editTextTaskDensity)).getText().toString());
        }catch(Exception e){
            e.printStackTrace();
            return;
        }



        ContentValues contentValues = new ContentValues();
        // Insert new task data via a ContentResolver
        // Create new empty ContentValues object
        contentValues.put(TaskContract.TaskEntry.COLUMN_NAME, name);
        contentValues.put(TaskContract.TaskEntry.COLUMN_POPULATION, population);
        contentValues.put(TaskContract.TaskEntry.COLUMN_AREA, area);
        contentValues.put(TaskContract.TaskEntry.COLUMN_GDP, GDP);
        contentValues.put(TaskContract.TaskEntry.COLUMN_POPULATION_DENSITY, density);

        // Insert the content values via a ContentResolver
        Uri uri = getContentResolver().insert(TaskContract.TaskEntry.CONTENT_URI, contentValues);

        // Display the URI that's returned with a Toast
        // [Hint] Don't forget to call finish() to return to MainActivity after this insert is complete
        if(uri != null) {
            Toast.makeText(getBaseContext(), uri.toString(), Toast.LENGTH_LONG).show();
        }

        // Finish activity (this returns back to MainActivity)
        finish();

    }
}
