package com.example.android.todolist;

import static org.junit.Assert.*;

public class MainActivityTest {

}