/*
* Copyright (C) 2016 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package com.example.android.todolist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

import com.example.android.todolist.CustomCursorAdapter.CustomCursorAdapterOnClickHandler;
import com.example.android.todolist.data.TaskContract;


public class MainActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor>  , CustomCursorAdapterOnClickHandler{



    private static final int MY_PERMISSION_RECORD_AUDIO_REQUEST_CODE = 88;

    int selection = 0;
    public static boolean selected = false;

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int TASK_LOADER_ID = 0;
    private CustomCursorAdapter mAdapter;
    RecyclerView mRecyclerView;
    private static final int MENU_MUSIC = Menu.FIRST,
            MENU_PLAY_MUSIC = Menu.FIRST + 1,
            MENU_STOP_PLAYING_MUSIC = Menu.FIRST + 2,
            MENU_ABOUT = Menu.FIRST + 3,
            MENU_EXIT = Menu.FIRST + 4;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        SubMenu subMenu = menu.addSubMenu(0, MENU_MUSIC, 0, "背景音樂")
                .setIcon(android.R.drawable.ic_media_ff);
        subMenu.add(0, MENU_PLAY_MUSIC, 0, "播放背景音樂");
        subMenu.add(0, MENU_STOP_PLAYING_MUSIC, 1, "停止播放背景音樂");




        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case MENU_PLAY_MUSIC:
                Intent it = new Intent(MainActivity.this, MediaPlayerService.class);
                startService(it);
                return true;
            case MENU_STOP_PLAYING_MUSIC:
                it = new Intent(MainActivity.this, MediaPlayerService.class);
                stopService(it);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        if(selected){
            Bundle bd =this.getIntent().getExtras();
            int a = bd.getInt("selection");
            putSelection(a);
        }


        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerViewTasks);


        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


        mAdapter = new CustomCursorAdapter(this,this);
        mRecyclerView.setAdapter(mAdapter);


        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }



            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int swipeDir) {

                int id = (int) viewHolder.itemView.getTag();


                String stringId = Integer.toString(id);
                Uri uri = TaskContract.TaskEntry.CONTENT_URI;
                uri = uri.buildUpon().appendPath(stringId).build();


                getContentResolver().delete(uri, null, null);


                getSupportLoaderManager().restartLoader(TASK_LOADER_ID, null, MainActivity.this);

            }
        }).attachToRecyclerView(mRecyclerView);


        FloatingActionButton fabButton = (FloatingActionButton) findViewById(R.id.fab);
        FloatingActionButton fabButton_sort = (FloatingActionButton) findViewById(R.id.fab_sort);
        FloatingActionButton fab_test = (FloatingActionButton) findViewById(R.id.fab_test) ;
        fabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent addTaskIntent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivity(addTaskIntent);
            }
        });
        fabButton_sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent sortIntent = new Intent(MainActivity.this, sort_activity.class);
                startActivity(sortIntent);
            }
        });

        fab_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent testIntent = new Intent(MainActivity.this,CardviewActivity.class);
                startActivity(testIntent);
            }
        });




        getSupportLoaderManager().initLoader(TASK_LOADER_ID, null, this);
    }


 /*   @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_RECORD_AUDIO_REQUEST_CODE: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    mAudioInputReader = new AudioInputReader(mVisualizerView, this);

                } else {
                    Toast.makeText(this, "Permission for audio not granted. Visualizer can't run.", Toast.LENGTH_LONG).show();
                    finish();

                }
            }

        }
    }*/

   /*private void setupPermissions() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                String[] permissionsWeNeed = new String[]{ Manifest.permission.RECORD_AUDIO };
                requestPermissions(permissionsWeNeed, MY_PERMISSION_RECORD_AUDIO_REQUEST_CODE);
            }
        } else {

            mAudioInputReader = new AudioInputReader(mVisualizerView, this);
        }
    }*/




    @Override
    protected void onResume() {
        super.onResume();


        getSupportLoaderManager().restartLoader(TASK_LOADER_ID, null, this);

    }



    public void putSelection(int selection){
        this.selection = selection;
    }
    @Override
    public Loader<Cursor> onCreateLoader(int id, final Bundle loaderArgs) {

        return new AsyncTaskLoader<Cursor>(this) {


            Cursor mTaskData = null;


            @Override
            protected void onStartLoading() {
                if (mTaskData != null) {

                    deliverResult(mTaskData);
                } else {

                    forceLoad();
                }
            }


            @Override
            public Cursor loadInBackground() {

                try {
                    switch (selection){
                        case 0:
                            return getContentResolver().query(TaskContract.TaskEntry.CONTENT_URI,
                                    null,
                                    null,
                                    null,
                                    TaskContract.TaskEntry.COLUMN_NAME);
                        case 1:
                            return getContentResolver().query(TaskContract.TaskEntry.CONTENT_URI,
                                    null,
                                    null,
                                    null,
                                    TaskContract.TaskEntry.COLUMN_POPULATION);
                        case 2:
                            return getContentResolver().query(TaskContract.TaskEntry.CONTENT_URI,
                                    null,
                                    null,
                                    null,
                                    TaskContract.TaskEntry.COLUMN_AREA);
                        case 3:
                            return getContentResolver().query(TaskContract.TaskEntry.CONTENT_URI,
                                    null,
                                    null,
                                    null,
                                    TaskContract.TaskEntry.COLUMN_GDP);
                        case 4:
                            return getContentResolver().query(TaskContract.TaskEntry.CONTENT_URI,
                                    null,
                                    null,
                                    null,
                                    TaskContract.TaskEntry.COLUMN_POPULATION_DENSITY);

                        default:
                            return getContentResolver().query(TaskContract.TaskEntry.CONTENT_URI,
                                null,
                                null,
                                null,
                                TaskContract.TaskEntry.COLUMN_NAME);

                    }

                } catch (Exception e) {
                    Log.e(TAG, "Failed to asynchronously load data.");
                    e.printStackTrace();
                    return null;
                }
            }


            public void deliverResult(Cursor data) {
                mTaskData = data;
                super.deliverResult(data);
            }
        };

    }



    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        mAdapter.swapCursor(data);
    }



    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
            mAdapter.swapCursor(null);
        }

    @Override
    public void onClick(String detail) {
        Bundle b = new Bundle();
        b.putString("detail",detail);

        Intent todetails = new Intent(MainActivity.this,detailsActivity.class);
        todetails.putExtras(b);
        startActivity(todetails);
    }

}

