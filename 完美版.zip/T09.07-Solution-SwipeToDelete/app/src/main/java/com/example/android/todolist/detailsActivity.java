package com.example.android.todolist;

import android.content.ContentValues;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.todolist.data.TaskContract;

import org.w3c.dom.Text;

public class detailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Bundle b = this.getIntent().getExtras();
        String s = b.getString("detail");
        TextView tv = (TextView) findViewById(R.id.showNameDetail);
        tv.setText(s);
    }


}
