from django.apps import AppConfig


class ConceptConfig(AppConfig):
    name = 'concept'
