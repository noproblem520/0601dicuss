package com.example.android.todolist;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Toast;

public class CardviewActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardview);


    }

    public void submitAnswer(View view){
        RadioGroup rg = (RadioGroup)findViewById(R.id.radioGroup);
        RadioButton rb = (RadioButton)findViewById(R.id.radioButton);
        int checkedID = rg.getCheckedRadioButtonId();
        LinearLayout bg = (LinearLayout) findViewById(R.id.bg);

        ScrollView sv = (ScrollView) findViewById(R.id.contenscrollView);
        switch(checkedID){

            case R.id.radioButton:
                Toast.makeText(this, "correct", Toast.LENGTH_SHORT).show();

                sv.setBackgroundColor(Color.GREEN);
                bg.setBackgroundColor(Color.GREEN);
                break;
            case R.id.radioButton2:
                Toast.makeText(this, "wrong", Toast.LENGTH_SHORT).show();
                sv.setBackgroundColor(Color.RED);
                bg.setBackgroundColor(Color.RED);
                break;
            case R.id.radioButton3:
                Toast.makeText(this, "wrong", Toast.LENGTH_SHORT).show();
                sv.setBackgroundColor(Color.RED);
                bg.setBackgroundColor(Color.RED);
                break;
                default:
                    Toast.makeText(this, String.valueOf(checkedID), Toast.LENGTH_SHORT).show();


        }
    }
}