package com.example.android.todolist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class sort_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sort);

        Button confirmBtn = (Button)findViewById(R.id.applySortingCondition);
        confirmBtn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                int selection = 0;
                Intent backToMain = new Intent(sort_activity.this,MainActivity.class);
                RadioGroup rg = (RadioGroup)findViewById(R.id.RG);
                int selectedID = rg.getCheckedRadioButtonId();
                Bundle passer = new Bundle();
                switch (selectedID){
                    case R.id.radioButtonName:
                      selection = 0;
                      break;
                    case R.id.radioButtonPopulation:
                        selection = 1;
                        break;
                    case R.id.radioButtonArea:
                        selection = 2;
                        break;
                    case R.id.radioButtonGDP:
                        selection = 3;
                        break;
                    case R.id.radioButtonDensity:
                        selection = 4;
                        break;
                }
                passer.putInt("selection",selection);
                backToMain.putExtras(passer);
                startActivity(backToMain);
                MainActivity.selected = true;
                finish();
            }
        });
    }


}
