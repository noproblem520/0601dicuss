/*
* Copyright (C) 2016 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package com.example.android.todolist;

import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.todolist.data.TaskContract;


/**


 * to a RecyclerView to efficiently display data.
 */
public class CustomCursorAdapter extends RecyclerView.Adapter<CustomCursorAdapter.TaskViewHolder> {

    private final CustomCursorAdapterOnClickHandler mClickHandler  ;


    public CustomCursorAdapter(Context mContext,CustomCursorAdapterOnClickHandler clickHandler) {
        this.mContext = mContext;
        mClickHandler = clickHandler;
    }

    public interface CustomCursorAdapterOnClickHandler {
        void onClick(String Detail);
    }



    // Inner class for creating ViewHolders
    class TaskViewHolder extends RecyclerView.ViewHolder implements OnClickListener {

        TextView nameView;
        TextView populationView;
        TextView GDPView;
        TextView areaView;
        TextView densityView;


        public TaskViewHolder(View itemView) {
            super(itemView);
            nameView = (TextView) itemView.findViewById(R.id.taskName);
            populationView = (TextView) itemView.findViewById(R.id.taskPopulation);
            areaView = (TextView) itemView.findViewById(R.id.taskArea);
            GDPView = (TextView) itemView.findViewById(R.id.taskGDP);
            densityView = (TextView) itemView.findViewById(R.id.taskDensity);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            String name = "國名 : "+ String.valueOf(nameView.getText().toString()) + " \n";
            String pop = "人口數 : "+String.valueOf(populationView.getText().toString()) + "萬 \n";
            String gdp = "GDP : "+String.valueOf(GDPView.getText().toString()) + "萬 \n";
            String area = "國土面積 : "+String.valueOf(areaView.getText().toString()) + "平方公里\n";
            String density = "人口密度 : "+String.valueOf(densityView.getText().toString())+"平方公里";
            mClickHandler.onClick(name + pop + gdp + area + density);

        }
    }



    // Class variables for the Cursor that holds task data and the Context
    private Cursor mCursor;
    private Context mContext;


    /**
     * Constructor for the CustomCursorAdapter that initializes the Context.
     *
     * @param mContext the current Context
     */



    /**
     * Called when ViewHolders are created to fill a RecyclerView.
     *
     * @return A new TaskViewHolder that holds the view for each task
     */
    @Override
    public TaskViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        // Inflate the task_layout to a view
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.task_layout, parent, false);

        return new TaskViewHolder(view);
    }


    /**
     * Called by the RecyclerView to display data at a specified position in the Cursor.
     *
     * @param holder The ViewHolder to bind Cursor data to
     * @param position The position of the data in the Cursor
     */
    @Override
    public void onBindViewHolder(TaskViewHolder holder, int position) {


        int idIndex = mCursor.getColumnIndex(TaskContract.TaskEntry._ID);
        int nameIndex = mCursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_NAME);
        int populationIndex = mCursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_POPULATION);
        int GDPIndex = mCursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_GDP);
        int areaIndex = mCursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_AREA);
        int densityIndex = mCursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_POPULATION_DENSITY);

        mCursor.moveToPosition(position); // get to the right location in the cursor

        // Determine the values of the wanted data
        final int id = mCursor.getInt(idIndex);
        String name = mCursor.getString(nameIndex);
        int population = mCursor.getInt(populationIndex);
        double area = mCursor.getDouble(areaIndex);
        double GDP = mCursor.getDouble(GDPIndex);
        double density = mCursor.getDouble(densityIndex);
        //Set values
        holder.itemView.setTag(id);
        holder.nameView.setText(name);
        holder.populationView.setText(String.valueOf(population));
        holder.areaView.setText(String.valueOf(area));
        holder.GDPView.setText(String.valueOf(GDP));
        holder.densityView.setText(String.valueOf(density));





    }




    /**
     * Returns the number of items to display.
     */
    @Override
    public int getItemCount() {
        if (mCursor == null) {
            return 0;
        }
        return mCursor.getCount();
    }


    /**
     * When data changes and a re-query occurs, this function swaps the old Cursor
     * with a newly updated Cursor (Cursor c) that is passed in.
     */
    public Cursor swapCursor(Cursor c) {
        // check if this cursor is the same as the previous cursor (mCursor)
        if (mCursor == c) {
            return null; // bc nothing has changed
        }
        Cursor temp = mCursor;
        this.mCursor = c; // new cursor value assigned

        //check if this is a valid cursor, then update the cursor
        if (c != null) {
            this.notifyDataSetChanged();
        }
        return temp;
    }



}