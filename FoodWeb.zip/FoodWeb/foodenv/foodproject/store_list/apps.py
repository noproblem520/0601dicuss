from django.apps import AppConfig


class StoreListConfig(AppConfig):
    name = 'store_list'
