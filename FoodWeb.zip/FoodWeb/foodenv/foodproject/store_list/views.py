from django.shortcuts import render_to_response
# Create your views here.
from .models import Store_list
from django.shortcuts import redirect

def store_list(request):
	stores = Store_list.objects.all()
	return render_to_response('store_list/list.html',locals())
def showpost(request,name):
	try:
		post = Store_list.objects.get(name = name)
		if post != None:
			return render(request,'store_list/post.html',locals())
	except:
		return redirect('/')