from django.shortcuts import render_to_response,render


def Index(request):
	return render(request,'index.html',locals())

def toRank(request):
	return render(request,'rank.html',locals())

def toRegister(request):
	return render(request,'register.html',locals())

def toOrigin(request):
	return render(request,'origin.html',locals())

