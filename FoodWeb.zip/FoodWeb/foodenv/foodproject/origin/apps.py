from django.apps import AppConfig


class OriginConfig(AppConfig):
    name = 'origin'
